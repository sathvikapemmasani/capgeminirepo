import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { DummyListComponent } from './dummy/dummy-list.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { EmployeeAddComponent } from './employee/employee-add.component';
import { PageNotFoundComponent } from './employee/page-not-found.component';
import { BrandComponent } from './dherbe/brand.component';
import { BranchComponent } from './dherbe/branch.component';
import { ContactComponent } from './dherbe/contact.component';
import { HomeComponent } from './dherbe/home.component';
import { UserroleComponent } from './dherbe/userrole.component';
import { APP_BASE_HREF } from '../../node_modules/@angular/common';
import { UseregisterComponent } from './dherbe/useregister.component';
import { UserloginComponent } from './dherbe/userlogin.component';
import { ProductComponent } from './dherbe/product.component';
import { EcobeautyComponent } from './dherbe/ecobeauty.component';
import { EcosanitationComponent } from './dherbe/ecosanitation.component';
import { Login1Component } from './log/login1.component';
import { EcosanitationAdminComponent } from './dherbe/ecosanitation-admin.component';
import { ForgotpasswordComponent } from './dherbe/forgotpassword.component';
import { ChangepasswordComponent } from './dherbe/changepassword.component';
import { AdminComponent } from './dherbe/admin.component';
import { EcobeautyAdminComponent } from './dherbe/ecobeauty-admin.component';
import { LoginEcoBeautyComponent } from './dherbe/login-eco-beauty.component';
import { ProductsLoginComponent } from './dherbe/products-login.component';
import { LoginEcoSanitationComponent } from './dherbe/login-eco-sanitation.component';
import { UpdateSanitationComponent } from './dherbe/update-sanitation.component';
import { UpdateBeautyComponent } from './dherbe/update-beauty.component';
import { SuperUserComponent } from './dherbe/super-user.component';
import { LogoutComponent } from './dherbe/logout.component';
import { LogoutSuccessComponent } from './dherbe/logout-success.component';




@NgModule({
  declarations: [
    AppComponent,
    DummyListComponent,
    EmployeeListComponent,
    EmployeeAddComponent,
    PageNotFoundComponent,
    BrandComponent,
    BranchComponent,
    ContactComponent,
    HomeComponent,
    UserroleComponent,
    UseregisterComponent,
    UserloginComponent,
    ProductComponent,
    EcobeautyComponent,
    EcosanitationComponent,
    Login1Component,
    EcosanitationAdminComponent,
    ForgotpasswordComponent,
    ChangepasswordComponent,
    AdminComponent,
    EcobeautyAdminComponent,
    LoginEcoBeautyComponent,
    ProductsLoginComponent,
    LoginEcoSanitationComponent,
    UpdateSanitationComponent,
    UpdateBeautyComponent,
    SuperUserComponent,
    LogoutComponent,
    LogoutSuccessComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [{ provide: APP_BASE_HREF, useValue: '/' }],
  bootstrap: [AppComponent]
})
export class AppModule { }
