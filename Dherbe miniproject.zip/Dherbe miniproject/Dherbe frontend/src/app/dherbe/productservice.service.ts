import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  constructor(private http:HttpClient) { }

  
    getAllProducts(){
      return this.http.get("http://localhost:9988/dherbesanitation/getalldataSanitation");
   }
   getAllSaniProducts(){
    return this.http.get("http://localhost:9988/dherbesanitation/getalldataSanitation");
 }

   getBeautyProducts(){
    return this.http.get("http://localhost:9988/dherbe/getalldata");

   }
    addUserRegister(data:any){
      console.log("service"+data)
      let userinput={"mobileNo":data.mobile,
      "userName":data.username,
       "address":data.address,
       "gender":data.gender,
      "role":data.role,
     "password":data.password,
     "email":data.email,
    "securityquestion":data.securityQuestion,
  "answer":data.answer}
     console.log(data.mobile);
     console.log("service"+data.role);
      return this.http.post("http://localhost:9699/userregister/adduser",userinput);
    }
baseurl="http://localhost:9988/dherbesanitation/searchbyid";
    getSanitationById(id:number){
      console.log("service");
      console.log(id);
      return this.http.get("${this.baseuerl}/${id}");

    }

    checkMobile(mobile:number,pwd:String){
      console.log("service");
      console.log(mobile);
      console.log(pwd);
      return this.http.get("http://localhost:9699/userregister/validate/"+mobile+"/"+pwd);

    }
    checkForgotPassword(mobile:number,answer:String){
      console.log("service");
      console.log(mobile);
      console.log(answer);
      return this.http.get("http://localhost:9699/userregister/getProductByMobileandanswer/"+mobile+"/"+answer);

    }

    changePassword(mobile:number,pwd:String){
      console.log("service");
      console.log(mobile);
      console.log(pwd);
      return this.http.put("http://localhost:9699/userregister/confirmPassword/"+mobile+"/"+pwd,+mobile);

    }

    adminDetails(mobile:number,pwd:String){
      
      console.log("service");
      console.log(mobile);
      console.log(pwd);
      return this.http.get("http://localhost:9699/userregister/admindetails/"+mobile+"/"+pwd);
    }
    saveProfile(file:File):Observable<any>{
      const formdata=new FormData();
      formdata.append('file',file);
      console.log("hlo");
      return this.http.post("http://localhost:9699/dherbesanitation/saveProduct",formdata,{
        reportProgress:true,responseType:'text'
      });
    }
    getdata(){
      return this.http.get("http://localhost:9699/dherbesanitation/getalldataSanitation");
    }
    getBeautydata(){
      return this.http.get("http://localhost:9699/dherbe/getalldata");
    }
    beautySaveProfile(file:File):Observable<any>{
      const formdata=new FormData();
      formdata.append('file',file);
      console.log("service hlo");
      return this.http.post("http://localhost:9699/dherbe/saveBeautyProduct",formdata,{
        reportProgress:true,responseType:'text'
      });
    }

    addProduct(data:any){
      let input={"prodId":data.prodid,
    "prodName":data.prodname,
    "prodPrice":data.prodprice,
    "stock":data.stock,
    "weight":data.weight,
    "guidelines":data.guidelines,
    "eDate":data.eDate,
  }; 
  return this.http.post("http://localhost:9988/dherbesanitation/adddataSanitation",input);
  }

  updateSanitationProduct(id:String,price:String,stock:String){
   console.log("service"+id+""+stock+""+price);
  return this.http.put("http://localhost:9699/dherbesanitation/updateProduct/"+id+"/"+price+"/"+stock,+id);
}


addBeautyProduct(data:any){
  let input={"prodId":data.prodid,
"prodName":data.prodname,
"prodPrice":data.prodprice,
"stock":data.stock,
"weight":data.weight,
"guidelines":data.guidelines,
"eDate":data.eDate,
}; 
return this.http.post("http://localhost:9988/dherbesanitation/adddata",input);
}
baseurl1='http://localhost:9988/dherbesanitation/productsByName'
getSanitationProdutByName(name:String){
  return this.http.get(`${this.baseurl1}/${name}`);
}

updateBeautyProduct(id:String,price:String,stock:String){
  console.log("service"+id+""+stock+""+price);
 return this.http.put("http://localhost:9699/dherbe/updateProduct/"+id+"/"+price+"/"+stock,+id);
}
deleteBeautyProduct(pro){
  return this.http.delete("http://localhost:9699/dherbe/deleteProduct/" +pro.prodId);
}


deleteSanitationProduct(pro){
  return  this.http.delete("http://localhost:9699/dherbesanitation/deleteProduct/" +pro.prodId);
}

getUserdata(){
  return this.http.get("http://localhost:9699/userregister/getalluserdetails");
}
deleteUser(user){
  return  this.http.delete("http://localhost:9699/userregister/deleteUser/" +user.mobileNo);

}

}
