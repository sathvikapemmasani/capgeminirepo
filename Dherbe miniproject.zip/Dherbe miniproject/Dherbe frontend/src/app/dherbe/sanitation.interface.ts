export class Sanitation{
    prodId:String;
    prodName:String;
   prodPrice:String;
   stock:String;
   weight:String;
   guidelines:String;
   eDate:String;
   image:String;

}