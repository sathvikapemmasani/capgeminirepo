package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.DherbeDao;
import com.cg.product.dto.DherbeBeauty;
@Service
public class DherbeServiceImpl implements DherbeService{
	@Autowired
	DherbeDao dao;
	@Override
	public List<DherbeBeauty> showAllProducts() {
		// TODO Auto-generated method stub
		return dao.showAllProducts();
	}

	

	@Override
	public DherbeBeauty searchByProductId(int proId) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void saveProduct(DherbeBeauty dherbebeauty) {
		dao.saveProduct(dherbebeauty);
		
	}



	@Override
	public void deleteProduct(String proId) {
		// TODO Auto-generated method stub
		dao.deleteProduct(proId);
	}



	@Override
	public DherbeBeauty updateProduct(String proid, String price, String stock) {
		// TODO Auto-generated method stub
		return dao.updateProduct(proid, price, stock);
	}

	

	
}
