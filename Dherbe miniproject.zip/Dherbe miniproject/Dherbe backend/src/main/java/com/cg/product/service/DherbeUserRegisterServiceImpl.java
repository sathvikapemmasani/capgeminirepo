package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.DherbeUserRegisterDao;
import com.cg.product.dto.DherbeSanitation;
import com.cg.product.dto.UserRegister;

@Service
public class DherbeUserRegisterServiceImpl implements DherbeUserRegisterService
{
@Autowired
DherbeUserRegisterDao dherbeUserRegisterDao;
	@Override
	public UserRegister addNewUser(UserRegister user) {
		// TODO Auto-generated method stub
		return dherbeUserRegisterDao.addNewUser(user);
	}
	@Override
	public boolean validateMobileandAnswer(Long mobileno, String answer) {
		// TODO Auto-generated method stub
		return dherbeUserRegisterDao.validateMobileandAnswer(mobileno, answer);
	}
	@Override
	public boolean validateUserLogin(Long username, String password) {
		
		return dherbeUserRegisterDao.validateUserLogin(username, password);
	}
	@Override
	public void updatepassword(Long mobile, String pwd) {
		dherbeUserRegisterDao.updatepassword(mobile, pwd);
		
	}
	@Override
	public String getAdminndSuperUserDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		return dherbeUserRegisterDao.getAdminndSuperUserDetails(mobile, password);
	}
	@Override
	public List<UserRegister> getAllUserDeatils() {
		// TODO Auto-generated method stub
		return dherbeUserRegisterDao.getAllUserDeatils();
	}
	@Override
	public void deleteUser(Long mobileNo) {
		// TODO Auto-generated method stub
		System.out.println("service"+mobileNo);
		dherbeUserRegisterDao.deleteUser(mobileNo);
	}
	

}
