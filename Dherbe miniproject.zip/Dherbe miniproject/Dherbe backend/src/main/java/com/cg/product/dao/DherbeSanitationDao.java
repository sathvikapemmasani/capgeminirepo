package com.cg.product.dao;

import java.util.List;

import com.cg.product.dto.DherbeSanitation;


public interface DherbeSanitationDao{
public List<DherbeSanitation> showAllProducts();
	
	public DherbeSanitation find(int proId);
	public DherbeSanitation saveProduct(DherbeSanitation dherbeSanitation);
	public List<DherbeSanitation> getProductByName(String prodName);
	public void deleteProduct(String proId); 
	public DherbeSanitation updateProduct(String proid,String price,String stock);
	
}
