package com.cg.product.dto;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "dherbe_userRegister")
public class UserRegister {

	@Id
//	@Indexed(name="_id")
	private Long mobileNo;
	private String userName;
	private String address;
	private String gender;
	private String role;
	private String password;
	private String email;
	private String securityquestion;
	private String answer;
	
	public UserRegister() {
		
	}

	public String getSecurityquestion() {
		return securityquestion;
	}

	public void setSecurityquestion(String securityquestion) {
		this.securityquestion = securityquestion;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public UserRegister(String securityquestion, String answer) {
		super();
		this.securityquestion = securityquestion;
		this.answer = answer;
	}

	public UserRegister(Long mobileNo, String userName, String address, String gender, String role,
			String password, String email) {
		super();
		
		this.mobileNo = mobileNo;
		this.userName = userName;
		this.address = address;
		this.gender = gender;
		this.role = role;
		this.password = password;
		this.email = email;
	}

	

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "UserRegister [ mobileNo=" + mobileNo + ", userName=" + userName + ", address="
				+ address + ", gender=" + gender + ", role=" + role + ", password=" + password + ", email=" + email
				+ ", securityquestion=" + securityquestion + ", answer=" + answer + "]";
	}

	

	
	
	
	

}
