package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.DherbeSanitationDao;
import com.cg.product.dto.DherbeSanitation;

@Service
public class DherbeSanitationImpl implements DherbeSanitationSer{

	@Autowired
	DherbeSanitationDao dao;

	@Override
	public List<DherbeSanitation> showAllProducts() {
		// TODO Auto-generated method stub
		return dao.showAllProducts();
	}



	@Override
	public DherbeSanitation searchByProductId(int proId) {
		
		return dao.find(proId);
	}



	@Override
	public DherbeSanitation saveProduct(DherbeSanitation dherbeSanitation) {
		// TODO Auto-generated method stub
		return dao.saveProduct(dherbeSanitation);
	}



	@Override
	public List<DherbeSanitation> getProductByName(String prodName) {
		// TODO Auto-generated method stub
		return dao.getProductByName(prodName);
	}



	@Override
	public void deleteProduct(String proId) {
		dao.deleteProduct(proId);
		
	}



	@Override
	public DherbeSanitation updateProduct(String proid,String price,String stock) {
		// TODO Auto-generated method stub
		return dao.updateProduct(proid,price,stock);
	}

	
	

}
