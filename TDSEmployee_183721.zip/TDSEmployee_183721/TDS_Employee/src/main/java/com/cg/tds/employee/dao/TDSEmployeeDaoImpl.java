package com.cg.tds.employee.dao;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.tds.employee.dto.TDSEmployee;

@Repository
public class TDSEmployeeDaoImpl implements TDSEmployeeDao{
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public List<TDSEmployee> showAllEmployee() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(TDSEmployee.class);
	}

	@Override
	public TDSEmployee addEmployee(TDSEmployee emp) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(emp);
	}

	@Override
	public TDSEmployee searchEmployeeById(int id) {
		// TODO Auto-generated method stub
		Query query=Query.query(Criteria.where("id").is(id));
		//Query query=Query.query(Criteria.where("id").is(id));
		TDSEmployee emp= mongotemplate.findOne(query, TDSEmployee.class); 
		return  emp;

	}

}
