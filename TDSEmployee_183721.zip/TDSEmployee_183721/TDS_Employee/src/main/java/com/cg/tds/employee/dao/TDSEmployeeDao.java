package com.cg.tds.employee.dao;

import java.util.List;

import com.cg.tds.employee.dto.TDSEmployee;

public interface TDSEmployeeDao {
	public List<TDSEmployee> showAllEmployee();
	public TDSEmployee addEmployee(TDSEmployee emp);
	public TDSEmployee searchEmployeeById(int empId);


}
