package com.cg.tds.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.tds.employee")

public class TdsEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TdsEmployeeApplication.class, args);
		System.out.println("welcome to tds employee details with mongo");
	}

}
