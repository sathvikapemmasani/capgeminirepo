package com.cg.tds.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tds.employee.dao.TDSEmployeeDao;
import com.cg.tds.employee.dto.TDSEmployee;

@Service
public class TDSEmployeeServiceImpl implements TDSEmployeeService {
	@Autowired
	TDSEmployeeDao tdsemployeedao;

	/***
	 * Author:P.Sathvika
	 * Date of Creation: 05-08-2019
	 * Method Name:showAllEmployee
	 * return Value:show all the employee details that are present in collection
	 * purpose:To see the employee details into Employee collection
	 */
	@Override
	public List<TDSEmployee> showAllEmployee() {
		// TODO Auto-generated method stub
		return tdsemployeedao.showAllEmployee();
	}
	/***
	  * Author:P.Sathvika
	 * Date of Creation: 05-08-2019
	 * Method Name:addAllEmployee
	 * Parameters:1 parameter of type TDSEmployee
	 * return Value:adds details to TDSEmployee Collection
	 * purpose:To save the employee details into Employee table
	 */
	@Override
	public TDSEmployee addEmployee(TDSEmployee emp) {
		// TODO Auto-generated method stub
		return tdsemployeedao.addEmployee(emp);
	}
	/***
	 * Author:P.Sathvika
	 * Date of Creation: 05-08-2019
	 * Method Name:searchEmployeeById
	 * Parameters:1 parameter of type Integer
	 * return Value:able to search details from the TDSEmployee collection
	 * purpose:To search a particular employee details from  TDSEmployee collection
	 */
	@Override
	public TDSEmployee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return tdsemployeedao.searchEmployeeById(empId);
	}

}
