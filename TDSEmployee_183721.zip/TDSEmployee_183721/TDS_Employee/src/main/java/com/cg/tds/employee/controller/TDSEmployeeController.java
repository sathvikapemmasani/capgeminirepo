package com.cg.tds.employee.controller;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.tds.employee.dto.TDSEmployee;
import com.cg.tds.employee.service.TDSEmployeeService;

@RestController
@RequestMapping("/TDSEmployee")
public class TDSEmployeeController {
	@Autowired
	TDSEmployeeService tdsemployeeservice;
	
	/***
	 * Author:P.Sathvika
	 * Date of Creation: 05-08-2019
	 * Method Name:getallEmployee
	 * return Value:get all the employee details if data not null,if null then return a message
	 * purpose:To see the employee details into Employee collection
	 */
	@GetMapping("/getall")
	public ResponseEntity<List<TDSEmployee>> getAllEmployee(){
		
		List<TDSEmployee> mylist=tdsemployeeservice.showAllEmployee();
		ZonedDateTime time1=ZonedDateTime.now();
		if(mylist.isEmpty()) {
			

			return new ResponseEntity("{"+"'timestramp'"+":"+time1.getNano()+" "+"\n"+"messsage:"+"Not Able to fetch the data"+"\n"+"details:"+"url=/user/tds/"+"}",
					HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity(mylist,HttpStatus.OK);
		
	}
	
	/***
	  * Author:P.Sathvika
	 * Date of Creation: 05-08-2019
	 * Method Name:addAllEmployee
	 * Parameters:1 parameter of type TDSEmployee
	 * return Value:adds details to TDSEmployee Collection if not null,else show a message
	 * purpose:To save the employee details into Employee table
	 */
	@PostMapping("/addall")
	public ResponseEntity<TDSEmployee> addAllEmployee(@RequestBody TDSEmployee emp) {
		TDSEmployee data= tdsemployeeservice.addEmployee(emp);
		ZonedDateTime time2=ZonedDateTime.now();
		 if(data==null)
		 {
			 return new ResponseEntity("{"+"'timestramp'"+":"+time2.getNano()+" "+"\n"+"messsage:"+"please insert data..."+"\n"+"details:"+"url=/user/tds/"+"}",
						HttpStatus.NOT_FOUND);
		 }
		return new ResponseEntity(data,HttpStatus.OK);
	}
	
	/***
	  * Author:P.Sathvika
	 * Date of Creation: 05-08-2019
	 * Method Name:searchByEmployeeId
	 * Parameters:1 parameter of type TDSEmployee
	 * return Value:search a particular employee details from  TDSEmployee Collection if not null,else show a message
	 * purpose:To save the employee details into Employee table
	 */
	@GetMapping("/searchbyid")
	public ResponseEntity<TDSEmployee> searchByEmployeeId(@RequestParam("eid") int empId ) {
	
		TDSEmployee data1= tdsemployeeservice.searchEmployeeById(empId);
		ZonedDateTime time=ZonedDateTime.now();
		if(data1==null) {
			
			return new ResponseEntity("{"+"'timestramp'"+":"+time.getNano()+" "+"\n"+"messsage:"+"ID not found wrong Id:"+empId+"\n"+"details:"+"url=http://localhost:9888/TDSEmployee/searchbyid?eid="+empId+"/user/tds/"+empId+"}",
					HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity(data1,HttpStatus.OK);
	
	}
	

}
