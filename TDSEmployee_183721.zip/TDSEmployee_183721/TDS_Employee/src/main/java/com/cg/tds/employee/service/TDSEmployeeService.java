package com.cg.tds.employee.service;

import java.util.List;

import com.cg.tds.employee.dto.TDSEmployee;

public interface TDSEmployeeService {
	public List<TDSEmployee> showAllEmployee();
	public TDSEmployee addEmployee(TDSEmployee emp);
	public TDSEmployee searchEmployeeById(int empId);


}
