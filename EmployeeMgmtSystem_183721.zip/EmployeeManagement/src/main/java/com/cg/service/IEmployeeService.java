package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;


public interface IEmployeeService {
	List<Employee> createEmployee(Employee employee) throws EmployeeException;

	List<Employee> ViewEmployees();
	
	
	Employee updateEmployee(Employee employee,Integer e);
	

	void deleteEmployee(Integer empid);
	

	//Employee updateEmployee(Integer e);
	
	
	Employee getEmployeeById(Integer empid);
	List<Employee> getEmployeeByDeptName(String deptName);

}
