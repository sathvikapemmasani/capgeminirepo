package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Employee;

import com.cg.dao.IEmployeeRepo;
import com.cg.exception.EmployeeException;
import com.cg.exception.ExceptionMessages;

@Service
public class EmployeeServiceImpl implements IEmployeeService{
	@Autowired
	private IEmployeeRepo repo;

	@Override
	public List<Employee> createEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		try {
			repo.save(employee);
			}catch(Exception exception) {
				throw new EmployeeException(ExceptionMessages.MESSAGE);
			}
			return  repo.findAll();
		
	}

	@Override
	public List<Employee> ViewEmployees() {
		return  repo.findAll();
	}

	@Override
	public Employee updateEmployee(Employee employee, Integer e) {
		// TODO Auto-generated method stub
		Optional<Employee> emp1=repo.findById(e);
		Employee emp=emp1.get();
		emp.setName(employee.getName());
		emp.setDesignation(employee.getDesignation());
		emp.setDeptname(employee.getDeptname());
		emp.setSalary(employee.getSalary());
		
		repo.save(emp);
		return emp;
		
	}

	@Override
	public void deleteEmployee(Integer empid) {
		// TODO Auto-generated method stub
		repo.deleteById(empid);
		
	}

	/*
	 * @Override public Employee updateEmployee(Integer e) { // TODO Auto-generated
	 * method stub return null; }
	 */

	@Override
	public Employee getEmployeeById(Integer empId) {
		// TODO Auto-generated method stub
		return repo.findById(empId).get();
	}

	@Override
	public List<Employee> getEmployeeByDeptName(String deptName) {
		// TODO Auto-generated method stub
		 List<Employee> list=repo.findAll();
		 List<Employee> list1=new ArrayList<>();
		 for(Employee employee:list) {
		  if(employee.getDeptname().equals(deptName)) {
		   list1.add(employee); 
		  }
		 }
		 return list1;
		}


	}


