package com.cg.exception;

public interface ExceptionMessages {
	String MESSAGE="data not saved due to internal error";

}
