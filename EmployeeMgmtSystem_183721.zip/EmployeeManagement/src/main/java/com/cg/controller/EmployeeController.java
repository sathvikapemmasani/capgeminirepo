package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.service.IEmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private IEmployeeService service;
	
	/* To Create employee data */
	
	@RequestMapping(value = "/createEmployee", method = RequestMethod.POST)
	public List<Employee> createEmployee(@RequestBody Employee employee) throws EmployeeException {
		return  service.createEmployee(employee);
	}
	
	/* To view all the employee */
	
	@RequestMapping(value = "/employees", method = RequestMethod.GET)
	public List<Employee> viewAllEmployees() {
		return  service.ViewEmployees();
	}
	
	
	/* to update an employee data */
	
	@RequestMapping(value = "/updateEmployee/{empid}", method = RequestMethod.PUT)
	public Employee updateEmployee(@RequestBody Employee employee,@PathVariable("empid")Integer e) {
		return  service.updateEmployee(employee, e);
	}
	
	/* to delete an employee record */
	
	@RequestMapping(value = "/deleteEmployee/{empid}", method = RequestMethod.DELETE)
	public String deleteEmployee(@PathVariable("empid") Integer EMP_ID ) {
		service.deleteEmployee(EMP_ID);
		return  EMP_ID+" is deleted";
	}
	
	/* to get employee details by ID and by department name */
	
	@RequestMapping(value = "/getEmployeeById/{empid}", method = RequestMethod.GET)
	public Employee getEmployeeById(@PathVariable("empid") Integer EMP_ID) {
		return service.getEmployeeById(EMP_ID);
	}

	@RequestMapping(value= "/employees/{name}", method = RequestMethod.GET)
    public List<Employee> getEmployeeByDeptName(@PathVariable("name") String n) {
    return service.getEmployeeByDeptName(n);
}
	


}
